# Python R6S парсер статистики облікового запису. 
![r6s_logo](https://upload.wikimedia.org/wikipedia/commons/a/a2/Rainbow_Six_siege_photo_2014-06-14_17-51.jpg)

[GitHub посилання](https://github.com/AlexProgramep/R6S_stats) 

`pip install r6s-account-stats`

``` 
from r6s import R6S 
R6S(nickname)
```